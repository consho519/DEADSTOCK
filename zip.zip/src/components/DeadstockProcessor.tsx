import React, { useState } from 'react';
import ExcelJS from 'exceljs';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { Upload, FileSpreadsheet, Settings, Play, CheckCircle2, AlertCircle, X, Clock } from 'lucide-react';

export default function DeadstockProcessor() {
  const [masterFile, setMasterFile] = useState<File | null>(null);
  const [branchFiles, setBranchFiles] = useState<File[]>([]);
  const [targetFrekuensi, setTargetFrekuensi] = useState<number>(12);
  const [targetFMos, setTargetFMos] = useState<number>(3);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [previewData, setPreviewData] = useState<{ headers: string[], rows: any[][] } | null>(null);
  const [processTime, setProcessTime] = useState<string | null>(null);

  const handleMasterUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setMasterFile(e.target.files[0]);
      setError(null);
      setSuccess(null);
    }
  };

  const handleBranchUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setBranchFiles((prev) => [...prev, ...newFiles]);
      setError(null);
      setSuccess(null);
    }
  };

  const removeBranchFile = (index: number) => {
    setBranchFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const readFileAsArrayBuffer = (file: File): Promise<ArrayBuffer> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as ArrayBuffer);
      reader.onerror = reject;
      reader.readAsArrayBuffer(file);
    });
  };

  const processExcel = async () => {
    if (!masterFile) {
      setError("Silakan unggah file Master terlebih dahulu.");
      return;
    }
    if (branchFiles.length === 0) {
      setError("Silakan unggah minimal 1 file Cabang Tujuan.");
      return;
    }

    const startTime = performance.now();
    setIsProcessing(true);
    setError(null);
    setSuccess(null);
    setProcessTime(null);

    try {
      // 1. Baca Master File menggunakan XLSX (Sangat Cepat)
      const masterBuffer = await readFileAsArrayBuffer(masterFile);
      const masterWb = XLSX.read(masterBuffer, { type: 'array' });
      const masterSheet = masterWb.Sheets[masterWb.SheetNames[0]];
      const masterData = XLSX.utils.sheet_to_json(masterSheet, { header: 1 }) as any[][];

      if (masterData.length < 2) throw new Error("File Master kosong atau tidak valid.");

      const masterHeaders = masterData[0];
      const masterRows = masterData.slice(1);

      // 2. Baca Branch Files secara paralel untuk kecepatan
      const branchDataMap: Record<string, Map<string, { stock: number, avgDemand: number, frekuensi: number }>> = {};
      
      await Promise.all(branchFiles.map(async (file) => {
        const buffer = await readFileAsArrayBuffer(file);
        // Optimasi pembacaan XLSX
        const wb = XLSX.read(buffer, { 
          type: 'array',
          cellDates: false,
          cellStyles: false,
          cellNF: false,
          cellText: false
        });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const data = XLSX.utils.sheet_to_json(sheet, { header: 1 }) as any[][];
        
        const branchMap = new Map();
        const branchName = file.name.replace(/\.[^/.]+$/, "");

        for (let i = 1; i < data.length; i++) {
          const row = data[i];
          const partCode = row[0]?.toString()?.trim(); // Kolom A
          if (partCode) {
            branchMap.set(partCode, {
              stock: Number(row[16]) || 0,      // Kolom Q (Index 16)
              frekuensi: Number(row[35]) || 0,  // Kolom AJ (Index 35)
              avgDemand: Number(row[36]) || 0,  // Kolom AK (Index 36)
            });
          }
        }
        branchDataMap[branchName] = branchMap;
      }));

      // 3. Siapkan Output menggunakan ExcelJS (Untuk Styling)
      const outputWorkbook = new ExcelJS.Workbook();
      const outputSheet = outputWorkbook.addWorksheet('Hasil Alokasi');

      // 4. Setup Header
      const allHeaders = [...masterHeaders.slice(0, 37)];
      branchFiles.forEach(file => {
        const branchName = file.name.replace(/\.[^/.]+$/, "").toUpperCase();
        allHeaders.push(
          `LAST COST ${branchName}`, 
          `AMOUNT ${branchName}`, 
          `AMBIL ${branchName}`, 
          `STOCK ${branchName}`, 
          `AVG DEMAND ${branchName}`, 
          `F MOS ${branchName}`, 
          `FREEK ${branchName}`
        );
      });

      const outHeaderRow = outputSheet.addRow(allHeaders);
      outHeaderRow.eachCell((cell, colNumber) => {
        cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
        cell.border = { top: {style:'thin'}, left: {style:'thin'}, bottom: {style:'thin'}, right: {style:'thin'} };
        
        if (colNumber <= 37) {
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF475569' } }; // Slate 600
        } else {
          const branchColIndex = (colNumber - 37 - 1) % 7;
          const color = branchColIndex === 2 ? 'FFCA8A04' : 'FF1E293B'; // Yellow-600 for AMBIL, Slate-800 for others
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: color } };
        }
      });

      // 5. Proses Baris (Logika Inti)
      const allOutputRows: any[][] = [];
      const previewRows: any[][] = [];

      for (const mRow of masterRows) {
        const partCode = mRow[0]?.toString()?.trim();
        if (!partCode) continue;

        const category = mRow[6]?.toString()?.trim()?.toUpperCase(); // Kolom G (Index 6)
        const lastCost = Number(mRow[4]) || 0; // Kolom E (Index 4)
        const originalMasterStock = Number(mRow[16]) || 0; // Kolom Q (Index 16)
        let remainingMasterStock = originalMasterStock;

        const rowData = [...mRow.slice(0, 37)];

        for (const file of branchFiles) {
          const branchName = file.name.replace(/\.[^/.]+$/, "");
          const bData = branchDataMap[branchName].get(partCode) || { stock: 0, avgDemand: 0, frekuensi: 0 };
          
          const { stock: bStock, avgDemand: bAvgDemand, frekuensi: bFreek } = bData;
          
          // Logika Cerdas: Hitung kebutuhan untuk mencapai target FMOS
          // Kebutuhan = (Target FMOS * Avg Demand) - Stock Saat Ini
          let needed = Math.max(0, Math.ceil((targetFMos * bAvgDemand) - bStock));
          let ambil = 0;
          
          if (category === 'D' && bFreek >= targetFrekuensi && needed > 0 && remainingMasterStock > 0) {
            ambil = Math.min(needed, remainingMasterStock);
            remainingMasterStock -= ambil;
          }

          // Hitung FMOS setelah alokasi (untuk laporan)
          let fMosAfter = bAvgDemand > 0 ? (ambil + bStock) / bAvgDemand : 0;

          rowData.push(
            lastCost,
            lastCost * originalMasterStock,
            ambil,
            bStock,
            bAvgDemand,
            Number(fMosAfter.toFixed(2)),
            bFreek
          );
        }

        allOutputRows.push(rowData);
        if (previewRows.length < 10) previewRows.push(rowData);
      }

      // Tambahkan semua baris sekaligus (Sangat Cepat)
      outputSheet.addRows(allOutputRows);

      // 6. Tulis File
      const buffer = await outputWorkbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      saveAs(blob, `Hasil_Alokasi_Deadstock_${new Date().getTime()}.xlsx`);
      
      const duration = ((performance.now() - startTime) / 1000).toFixed(2);
      setProcessTime(duration);
      setSuccess(`Berhasil! ${allOutputRows.length} baris diproses dalam ${duration} detik.`);
      setPreviewData({ headers: allHeaders, rows: previewRows });

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Terjadi kesalahan saat memproses data.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans text-slate-900">
      <div className="max-w-6xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-indigo-600 text-white rounded-xl shadow-indigo-200 shadow-lg">
              <FileSpreadsheet size={32} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Alokator Otomatis Deadstock</h1>
              <p className="text-slate-500 text-sm">Optimasi stok mati antar cabang dengan logika cerdas & cepat.</p>
            </div>
          </div>
          {processTime && (
            <div className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-full text-sm font-semibold border border-emerald-100">
              <Clock size={16} />
              Waktu Proses: {processTime}s
            </div>
          )}
        </div>

        {/* Configuration */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h2 className="text-lg font-semibold flex items-center gap-2 mb-4 text-slate-700">
            <Settings size={20} className="text-indigo-500" />
            Parameter Syarat Alokasi
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-slate-600">Minimal Target Frekuensi</label>
              <input 
                type="number" 
                value={targetFrekuensi}
                onChange={(e) => setTargetFrekuensi(Number(e.target.value))}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all bg-slate-50"
              />
              <p className="text-xs text-slate-400 italic">Cabang harus memiliki frekuensi penjualan &ge; angka ini.</p>
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-slate-600">Minimal Target F MOS</label>
              <input 
                type="number" 
                value={targetFMos}
                onChange={(e) => setTargetFMos(Number(e.target.value))}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all bg-slate-50"
              />
              <p className="text-xs text-slate-400 italic">Cabang harus memiliki F MOS &ge; angka ini.</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Master Upload */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col">
            <h2 className="text-lg font-semibold mb-4 text-slate-700">1. Unggah Data Master</h2>
            <div className="flex-1 border-2 border-dashed border-slate-200 rounded-2xl p-8 text-center hover:border-indigo-400 hover:bg-indigo-50/30 transition-all relative group">
              <input 
                type="file" 
                accept=".xlsx, .xls" 
                onChange={handleMasterUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <Upload className="mx-auto text-slate-300 group-hover:text-indigo-400 mb-4 transition-colors" size={48} />
              {masterFile ? (
                <div className="space-y-2">
                  <div className="text-emerald-600 font-bold flex items-center justify-center gap-2 bg-emerald-50 py-2 px-4 rounded-lg inline-flex">
                    <CheckCircle2 size={18} />
                    {masterFile.name}
                  </div>
                  <p className="text-xs text-slate-400">Klik untuk mengganti file</p>
                </div>
              ) : (
                <div className="space-y-1">
                  <p className="font-bold text-slate-600">Klik atau seret file Master ke sini</p>
                  <p className="text-sm text-slate-400">Format yang didukung: .xlsx, .xls</p>
                </div>
              )}
            </div>
          </div>

          {/* Branch Upload */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h2 className="text-lg font-semibold mb-4 text-slate-700">2. Unggah Data Cabang</h2>
            <div className="border-2 border-dashed border-slate-200 rounded-2xl p-8 text-center hover:border-indigo-400 hover:bg-indigo-50/30 transition-all relative mb-4 group">
              <input 
                type="file" 
                accept=".xlsx, .xls" 
                multiple
                onChange={handleBranchUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <Upload className="mx-auto text-slate-300 group-hover:text-indigo-400 mb-4 transition-colors" size={48} />
              <p className="font-bold text-slate-600">Unggah File Cabang (Bisa banyak sekaligus)</p>
              <p className="text-sm text-slate-400">Urutan unggah menentukan prioritas alokasi</p>
            </div>

            {/* Branch List */}
            {branchFiles.length > 0 && (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                {branchFiles.map((file, index) => (
                  <div key={index} className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-100 group">
                    <div className="flex items-center gap-3 overflow-hidden">
                      <div className="bg-indigo-600 text-white w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 shadow-sm">
                        {index + 1}
                      </div>
                      <span className="text-sm font-medium truncate text-slate-700">{file.name}</span>
                    </div>
                    <button 
                      onClick={() => removeBranchFile(index)}
                      className="text-slate-300 hover:text-red-500 transition-colors p-1"
                    >
                      <X size={18} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Action & Status */}
        <div className="flex flex-col items-center gap-4 py-4">
          {error && (
            <div className="flex items-center gap-3 text-red-600 bg-red-50 px-6 py-4 rounded-2xl w-full border border-red-100 shadow-sm animate-shake">
              <AlertCircle size={24} className="shrink-0" />
              <p className="text-sm font-bold">{error}</p>
            </div>
          )}
          
          {success && (
            <div className="flex items-center gap-3 text-emerald-700 bg-emerald-50 px-6 py-4 rounded-2xl w-full border border-emerald-100 shadow-sm">
              <CheckCircle2 size={24} className="shrink-0" />
              <p className="text-sm font-bold">{success}</p>
            </div>
          )}

          <button
            onClick={processExcel}
            disabled={isProcessing}
            className={`group relative flex items-center gap-3 px-12 py-5 rounded-2xl font-black text-lg text-white shadow-xl transition-all overflow-hidden ${
              isProcessing 
                ? 'bg-slate-400 cursor-not-allowed' 
                : 'bg-indigo-600 hover:bg-indigo-700 hover:shadow-indigo-200 hover:-translate-y-1 active:translate-y-0'
            }`}
          >
            {isProcessing ? (
              <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Play size={28} fill="currentColor" />
            )}
            <span>{isProcessing ? 'SEDANG MEMPROSES...' : 'PROSES & UNDUH EXCEL'}</span>
            {!isProcessing && (
              <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-500 skew-x-12" />
            )}
          </button>
        </div>

        {/* Preview Table */}
        {previewData && (
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 overflow-hidden animate-slideUp">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <div className="w-2 h-8 bg-indigo-600 rounded-full" />
                <h2 className="text-xl font-black text-slate-800">Review Hasil Samping (10 Baris)</h2>
              </div>
              <button 
                onClick={() => setPreviewData(null)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm flex items-center gap-1"
              >
                <X size={16} /> Tutup
              </button>
            </div>
            <div className="overflow-x-auto border border-slate-100 rounded-2xl shadow-inner">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-800 text-white font-bold">
                  <tr>
                    {previewData.headers.map((header, i) => (
                      <th key={i} className="px-4 py-4 whitespace-nowrap border-r border-slate-700 last:border-0 uppercase tracking-wider">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {previewData.rows.map((row, i) => (
                    <tr key={i} className="hover:bg-indigo-50/30 transition-colors">
                      {row.map((cell, j) => {
                        const isAmbil = previewData.headers[j]?.includes('AMBIL');
                        return (
                          <td 
                            key={j} 
                            className={`px-4 py-3 whitespace-nowrap border-r border-slate-100 last:border-0 font-medium ${
                              isAmbil ? 'bg-yellow-100 text-yellow-900 font-black border-yellow-200' : 'text-slate-600'
                            }`}
                          >
                            {typeof cell === 'object' ? JSON.stringify(cell) : String(cell ?? '')}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-4 flex items-center gap-2 text-slate-400 text-xs italic">
              <AlertCircle size={14} />
              <span>Hanya menampilkan 10 baris pertama untuk pengecekan cepat.</span>
            </div>
          </div>
        )}

      </div>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-4px); }
          75% { transform: translateX(4px); }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-shake { animation: shake 0.2s ease-in-out 0s 2; }
        .animate-slideUp { animation: slideUp 0.4s ease-out; }
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #cbd5e1; }
      `}</style>
    </div>
  );
}
